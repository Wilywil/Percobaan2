## X-random
Tools Installer 

# command install
```
pkg update && pkg upgrade
pkg install git
git clone https://github.com/kucing-hitam/X-random
cd X-random
ls
sh XXX.sh
```

# screenshot
<img src="https://i.ibb.co/t8d62XC/Screenshot-2019-12-16-16-02-00.png" border="0"> 
<img src="https://i.ibb.co/NxQTYJD/Screenshot-2019-12-16-16-02-59.png" border="0">

# contact me
* <a href="https://instagram.com/mhmaulna_">INSTAGRAM
* <a href="https://m.youtube.com/channel/UCSbcN5mn7yzxe_MXVF_Z6Fw">MY channel YOUTUBE
