#bin/bash

cy='\033[1;36m' #cyan
C='\033[0;36m'  #cyan gelap

clear
sleep 1
echo $cy"TUNGGU BENTAR..."
sleep 5
xdg-open https://youtu.be/oi5oJot0QE4
exit